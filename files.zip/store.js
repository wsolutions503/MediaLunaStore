// ─────────────────────────────────────────────
//  store.js — Firestore persistence layer
// ─────────────────────────────────────────────
import { db } from './firebase'
import {
  collection, doc, getDocs, getDoc,
  addDoc, setDoc, updateDoc, deleteDoc,
  query, orderBy, serverTimestamp, onSnapshot
} from 'firebase/firestore'

// ── Collections ────────────────────────────────────────────────────────────
export const COLS = {
  USERS:      'users',
  PRODUCTS:   'products',
  CATEGORIES: 'categories',
  SALES:      'sales',
  CUSTOMERS:  'customers',
  SETTINGS:   'settings',
}

// ── Generic helpers ────────────────────────────────────────────────────────
export async function getAll(col) {
  const snap = await getDocs(collection(db, col))
  return snap.docs.map(d => ({ id: d.id, ...d.data() }))
}

export async function getOne(col, id) {
  const snap = await getDoc(doc(db, col, id))
  return snap.exists() ? { id: snap.id, ...snap.data() } : null
}

export async function addItem(col, data) {
  const ref = await addDoc(collection(db, col), { ...data, createdAt: new Date().toISOString() })
  return { id: ref.id, ...data }
}

export async function setItem(col, id, data) {
  await setDoc(doc(db, col, id), data, { merge: true })
}

export async function updateItem(col, id, data) {
  await updateDoc(doc(db, col, id), data)
}

export async function deleteItem(col, id) {
  await deleteDoc(doc(db, col, id))
}

// ── Seed initial data (runs once if collections are empty) ──────────────────
export async function seedIfEmpty() {
  const users = await getAll(COLS.USERS)
  if (users.length === 0) {
    await setItem(COLS.USERS, 'u1', { name: 'Super Admin',     email: 'super@medialuna.sv', password: 'super123', role: 'superadmin', active: true, createdAt: new Date().toISOString() })
    await setItem(COLS.USERS, 'u2', { name: 'Administrador',   email: 'admin@medialuna.sv', password: 'admin123', role: 'admin',      active: true, createdAt: new Date().toISOString() })
    await setItem(COLS.USERS, 'u3', { name: 'Vendedor Demo',   email: 'venta@medialuna.sv', password: 'venta123', role: 'vendedor',   active: true, createdAt: new Date().toISOString() })
  }

  const cats = await getAll(COLS.CATEGORIES)
  if (cats.length === 0) {
    await setItem(COLS.CATEGORIES, 'c1', { name: 'Collares', icon: '📿', color: '#f0c060' })
    await setItem(COLS.CATEGORIES, 'c2', { name: 'Anillos',  icon: '💍', color: '#f472b6' })
    await setItem(COLS.CATEGORIES, 'c3', { name: 'Aretes',   icon: '✨', color: '#22d3ee' })
    await setItem(COLS.CATEGORIES, 'c4', { name: 'Pulseras', icon: '📿', color: '#a78bfa' })
    await setItem(COLS.CATEGORIES, 'c5', { name: 'Broches',  icon: '🔮', color: '#34d399' })
  }

  const settings = await getOne(COLS.SETTINGS, 'config')
  if (!settings) {
    await setItem(COLS.SETTINGS, 'config', { storeName: 'Media Luna Store', currency: 'USD', lowStockAlert: true })
  }
}

// ── Session (localStorage — solo local, no se comparte) ────────────────────
export function getSession()      { try { return JSON.parse(localStorage.getItem('glam_session')) } catch { return null } }
export function setSession(user)  { localStorage.setItem('glam_session', JSON.stringify(user)) }
export function clearSession()    { localStorage.removeItem('glam_session') }

export async function login(email, password) {
  const users = await getAll(COLS.USERS)
  const user  = users.find(u => u.email === email && u.password === password && u.active)
  if (user) { const { password: _, ...safe } = user; setSession(safe); return safe }
  return null
}

// ── Users ──────────────────────────────────────────────────────────────────
export const getUsers    = ()       => getAll(COLS.USERS)
export const addUser     = (data)   => addItem(COLS.USERS, data)
export const updateUser  = (id, d)  => updateItem(COLS.USERS, id, d)
export const deleteUser  = (id)     => deleteItem(COLS.USERS, id)

// ── Categories ─────────────────────────────────────────────────────────────
export const getCategories   = ()      => getAll(COLS.CATEGORIES)
export const addCategory     = (data)  => addItem(COLS.CATEGORIES, data)
export const deleteCategory  = (id)    => deleteItem(COLS.CATEGORIES, id)

// ── Products ───────────────────────────────────────────────────────────────
export const getProducts    = ()       => getAll(COLS.PRODUCTS)
export const addProduct     = (data)   => addItem(COLS.PRODUCTS, { ...data, active: true })
export const updateProduct  = (id, d)  => updateItem(COLS.PRODUCTS, id, d)
export const deleteProduct  = (id)     => deleteItem(COLS.PRODUCTS, id)

export async function getLowStockProducts() {
  const products = await getProducts()
  return products.filter(p => p.active && p.stock <= p.minStock)
}

// ── Customers ──────────────────────────────────────────────────────────────
export const getCustomers   = ()      => getAll(COLS.CUSTOMERS)
export const addCustomer    = (data)  => addItem(COLS.CUSTOMERS, data)
export const updateCustomer = (id, d) => updateItem(COLS.CUSTOMERS, id, d)

// ── Sales ──────────────────────────────────────────────────────────────────
export const getSales    = ()      => getAll(COLS.SALES)
export const updateSale  = (id, d) => updateItem(COLS.SALES, id, d)

export async function createSale(saleData) {
  // Deduct stock from each product
  for (const item of saleData.items) {
    const product = await getOne(COLS.PRODUCTS, item.productId)
    if (product) {
      await updateProduct(product.id, { stock: Math.max(0, product.stock - item.qty) })
    }
  }
  const newSale = {
    ...saleData,
    status: 'pendiente',
    paymentStatus: 'pendiente',
    createdAt: new Date().toISOString(),
  }
  return addItem(COLS.SALES, newSale)
}

// ── Settings ───────────────────────────────────────────────────────────────
export const getSettings  = ()    => getOne(COLS.SETTINGS, 'config')
export const saveSettings = (d)   => setItem(COLS.SETTINGS, 'config', d)

// ── Utils ──────────────────────────────────────────────────────────────────
export function fmt(n) {
  return new Intl.NumberFormat('es-SV', { style: 'currency', currency: 'USD' }).format(n || 0)
}

export function fmtDate(iso) {
  if (!iso) return '—'
  return new Date(iso).toLocaleDateString('es-SV', { day: '2-digit', month: 'short', year: 'numeric' })
}

export const CHANNELS      = ['WhatsApp', 'Instagram', 'Facebook', 'Tienda física', 'Otra']
export const CHANNEL_ICONS = { WhatsApp: '💬', Instagram: '📸', Facebook: '👥', 'Tienda física': '🏪', Otra: '🔗' }
export const ROLES         = { superadmin: 'SuperAdmin', admin: 'Administrador', vendedor: 'Vendedor' }

export const SALE_STATUS = {
  pendiente:  { label: 'Pendiente',  badge: 'badge-amber' },
  enviado:    { label: 'Enviado',    badge: 'badge-cyan'  },
  entregado:  { label: 'Entregado', badge: 'badge-green' },
  cancelado:  { label: 'Cancelado', badge: 'badge-red'   },
}

export const PAY_STATUS = {
  pendiente: { label: 'Sin pagar', badge: 'badge-red'   },
  pagado:    { label: 'Pagado',    badge: 'badge-green' },
  parcial:   { label: 'Parcial',   badge: 'badge-amber' },
}
